
import GoogleSheetsSettings from '@/components/google-sheets-settings';

export default function GoogleSheetsPage() {
  return <GoogleSheetsSettings />;
}
