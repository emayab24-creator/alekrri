
import SheetsProcessor from '@/components/SheetsProcessor';

export default function SheetsPage() {
  return (
    <div className="container mx-auto py-6">
      <SheetsProcessor />
    </div>
  );
}
